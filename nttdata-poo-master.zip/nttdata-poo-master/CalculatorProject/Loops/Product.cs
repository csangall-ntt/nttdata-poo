﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorProject.Loops
{
    public class Product
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public float Price { get; set; }
    }
}
